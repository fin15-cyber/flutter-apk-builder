"use strict";


/* =================================
   ELEMENT
================================= */

const camera =
    document.getElementById("camera");

const overlay =
    document.getElementById("overlay");

const ctx =
    overlay.getContext("2d");

const startBtn =
    document.getElementById("startBtn");

const photoBtn =
    document.getElementById("photoBtn");

const tutorialBtn =
    document.getElementById("tutorialBtn");

const musicBtn =
    document.getElementById("musicBtn");

const music =
    document.getElementById("music");

const tutorial =
    document.getElementById("tutorial");

const closeTutorial =
    document.getElementById("closeTutorial");

const speakBtn =
    document.getElementById("speakBtn");

const voiceStatus =
    document.getElementById("voiceStatus");

const state =
    document.getElementById("state");

const blurLabel =
    document.getElementById("blurLabel");

const gestureHint =
    document.getElementById("gestureHint");

const loveContainer =
    document.getElementById("loveContainer");


/* =================================
   STATE
================================= */

let cameraStarted = false;

let blurActive = false;

let processing = false;

let lastProcess =
    0;

let loveTimer = null;


/* =================================
   CANVAS
================================= */

function resizeCanvas() {

    const dpr =
        Math.min(
            window.devicePixelRatio || 1,
            1.5
        );


    overlay.width =
        Math.floor(
            innerWidth * dpr
        );


    overlay.height =
        Math.floor(
            innerHeight * dpr
        );


    overlay.style.width =
        innerWidth + "px";


    overlay.style.height =
        innerHeight + "px";


    ctx.setTransform(
        dpr,
        0,
        0,
        dpr,
        0,
        0
    );

}


resizeCanvas();


window.addEventListener(
    "resize",
    resizeCanvas
);


/* =================================
   CAMERA
================================= */

startBtn.addEventListener(
    "click",
    startCamera
);


async function startCamera() {

    if (cameraStarted) {
        return;
    }


    if (
        !navigator.mediaDevices ||
        !navigator.mediaDevices.getUserMedia
    ) {

        alert(
            "Browser tidak mendukung kamera."
        );

        return;

    }


    try {

        const stream =
            await navigator.mediaDevices
                .getUserMedia({

                    audio: false,

                    video: {

                        facingMode:
                            "user",

                        width: {
                            ideal: 480
                        },

                        height: {
                            ideal: 360
                        },

                        frameRate: {
                            ideal: 20,
                            max: 24
                        }

                    }

                });


        camera.srcObject =
            stream;


        await camera.play();


        cameraStarted =
            true;


        startBtn.textContent =
            "AKTIF";


        startBtn.disabled =
            true;


        gestureHint.textContent =
            "Mencari tangan...";


        startTracking();


    } catch (error) {

        console.error(
            error
        );


        alert(
            "Kamera tidak bisa dibuka. Izinkan akses kamera dan gunakan HTTPS/Preview Acode."
        );

    }

}


/* =================================
   MEDIAPIPE
================================= */

const hands =
    new Hands({

        locateFile:
            file => {

                return (
                    "https://cdn.jsdelivr.net/npm/@mediapipe/hands/" +
                    file
                );

            }

    });


hands.setOptions({

    maxNumHands: 1,

    modelComplexity: 0,

    minDetectionConfidence: .65,

    minTrackingConfidence: .55

});


hands.onResults(
    handleHands
);


/* =================================
   HAND RESULTS
================================= */

function handleHands(
    results
) {

    drawHand(
        results
    );


    const detected =
        results.multiHandLandmarks &&
        results.multiHandLandmarks.length;


    if (!detected) {

        setBlur(false);

        gestureHint.textContent =
            "Tunjukkan tangan ke kamera";

        return;

    }


    const hand =
        results.multiHandLandmarks[0];


    const index =
        isFingerOpen(
            hand,
            8,
            6
        );


    const middle =
        isFingerOpen(
            hand,
            12,
            10
        );


    const ring =
        isFingerClosed(
            hand,
            16,
            14
        );


    const pinky =
        isFingerClosed(
            hand,
            20,
            18
        );


    /*
     * Gesture PEACE ✌️
     */

    const peace =
        index &&
        middle &&
        ring &&
        pinky;


    if (peace) {

        setBlur(true);

        gestureHint.textContent =
            "✌️ BLUR AKTIF";

    } else {

        setBlur(false);

        gestureHint.textContent =
            "✌️ = BLUR";

    }

}


/* =================================
   FINGER CHECK
================================= */

function isFingerOpen(
    hand,
    tip,
    joint
) {

    return (
        hand[tip].y <
        hand[joint].y - .025
    );

}


function isFingerClosed(
    hand,
    tip,
    joint
) {

    return (
        hand[tip].y >
        hand[joint].y - .005
    );

}


/* =================================
   DRAW LANDMARK
================================= */

function drawHand(
    results
) {

    ctx.clearRect(
        0,
        0,
        innerWidth,
        innerHeight
    );


    if (
        !results.multiHandLandmarks ||
        !results.multiHandLandmarks.length
    ) {

        return;

    }


    const hand =
        results.multiHandLandmarks[0];


    /*
     * Hanya titik ujung jari.
     * Lebih ringan.
     */

    const points = [
        4,
        8,
        12,
        16,
        20
    ];


    ctx.fillStyle =
        "rgba(255,255,255,.9)";


    for (
        const index of points
    ) {

        const point =
            hand[index];


        const x =
            (1 - point.x) *
            innerWidth;


        const y =
            point.y *
            innerHeight;


        ctx.beginPath();


        ctx.arc(
            x,
            y,
            4,
            0,
            Math.PI * 2
        );


        ctx.fill();

    }

}


/* =================================
   BLUR
================================= */

function setBlur(
    value
) {

    if (
        blurActive === value
    ) {

        return;

    }


    blurActive =
        value;


    if (value) {

        camera.classList.add(
            "blur"
        );


        state.textContent =
            "BLUR AKTIF";


        blurLabel.textContent =
            "BLUR ON";


        startLoveEffect();


    } else {

        camera.classList.remove(
            "blur"
        );


        state.textContent =
            "NORMAL";


        blurLabel.textContent =
            "BLUR OFF";


        stopLoveEffect();

    }

}


/* =================================
   LOVE EFFECT
================================= */

function createLove() {

    if (!blurActive) {
        return;
    }


    const love =
        document.createElement(
            "div"
        );


    love.className =
        "flyingLove";


    const emojis = [
        "❤️",
        "💗",
        "💕",
        "💖",
        "💘"
    ];


    love.textContent =
        emojis[
            Math.floor(
                Math.random() *
                emojis.length
            )
        ];


    love.style.left =
        (
            Math.random() *
            100
        ) + "%";


    love.style.setProperty(
        "--drift",
        (
            Math.random() *
            100 -
            50
        ) + "px"
    );


    love.style.animationDuration =
        (
            2.2 +
            Math.random() * .8
        ) + "s";


    loveContainer.appendChild(
        love
    );


    setTimeout(
        () => {

            love.remove();

        },
        3200
    );

}


function startLoveEffect() {

    if (loveTimer) {
        return;
    }


    createLove();


    loveTimer =
        setInterval(
            createLove,
            380
        );

}


function stopLoveEffect() {

    if (loveTimer) {

        clearInterval(
            loveTimer
        );

        loveTimer =
            null;

    }

}


/* =================================
   TRACKING
================================= */

function startTracking() {

    async function loop() {

        if (
            camera.readyState >= 2 &&
            !processing
        ) {

            const now =
                performance.now();


            /*
             * Sekitar 13 FPS.
             * Dibuat ringan untuk HP.
             */

            if (
                now - lastProcess >= 75
            ) {

                lastProcess =
                    now;


                processing =
                    true;


                try {

                    await hands.send({
                        image: camera
                    });

                } catch (error) {

                    console.error(
                        "Tracking:",
                        error
                    );

                }


                processing =
                    false;

            }

        }


        requestAnimationFrame(
            loop
        );

    }


    loop();

}


/* =================================
   PHOTO
================================= */

photoBtn.addEventListener(
    "click",
    takePhoto
);


function takePhoto() {

    if (!cameraStarted) {

        alert(
            "Aktifkan kamera dulu."
        );

        return;

    }


    const photo =
        document.createElement(
            "canvas"
        );


    photo.width =
        camera.videoWidth;


    photo.height =
        camera.videoHeight;


    const pctx =
        photo.getContext("2d");


    pctx.translate(
        photo.width,
        0
    );


    pctx.scale(
        -1,
        1
    );


    if (blurActive) {

        pctx.filter =
            "blur(18px)";

    }


    pctx.drawImage(
        camera,
        0,
        0,
        photo.width,
        photo.height
    );


    const link =
        document.createElement(
            "a"
        );


    link.download =
        "foto-kita-" +
        Date.now() +
        ".jpg";


    link.href =
        photo.toDataURL(
            "image/jpeg",
            .92
        );


    link.click();

}


/* =================================
   MUSIC
================================= */

musicBtn.addEventListener(
    "click",
    async () => {

        try {

            if (
                music.paused
            ) {

                await music.play();


                musicBtn.textContent =
                    "MUSIK ON";

            } else {

                music.pause();


                musicBtn.textContent =
                    "MUSIK OFF";

            }

        } catch (error) {

            alert(
                "Pastikan file lagu.mp3 ada di folder project."
            );

        }

    }
);


/* =================================
   TUTORIAL
================================= */

tutorialBtn.addEventListener(
    "click",
    () => {

        tutorial.classList.remove(
            "hidden"
        );

    }
);


closeTutorial.addEventListener(
    "click",
    () => {

        tutorial.classList.add(
            "hidden"
        );


        if (
            "speechSynthesis" in window
        ) {

            speechSynthesis.cancel();

        }

    }
);


/* =================================
   VOICE
================================= */

speakBtn.addEventListener(
    "click",
    () => {

        if (
            !("speechSynthesis" in window)
        ) {

            voiceStatus.textContent =
                "Browser tidak mendukung suara.";

            return;

        }


        speechSynthesis.cancel();


        const text =
            "Selamat datang di Foto Kita Blur. " +
            "Tekan tombol kamera untuk memulai. " +
            "Setelah kamera aktif, arahkan satu tangan ke kamera. " +
            "Bentuk tangan menjadi gesture peace atau dua jari. " +
            "Saat gesture peace terdeteksi, kamera akan otomatis blur dan emoji love akan terbang ke atas. " +
            "Saat gesture dilepas, kamera kembali normal. " +
            "Tekan foto untuk mengambil gambar dan tombol musik untuk memutar lagu.";


        const speech =
            new SpeechSynthesisUtterance(
                text
            );


        speech.lang =
            "id-ID";


        speech.rate =
            .9;


        speech.pitch =
            1;


        speech.onstart =
            () => {

                voiceStatus.textContent =
                    "Tutorial sedang berbicara...";

                speakBtn.textContent =
                    "SEDANG BERBICARA";

            };


        speech.onend =
            () => {

                voiceStatus.textContent =
                    "Tutorial selesai.";

                speakBtn.textContent =
                    "🔊 DENGARKAN LAGI";

            };


        speech.onerror =
            () => {

                voiceStatus.textContent =
                    "Suara gagal diputar.";

                speakBtn.textContent =
                    "COBA LAGI";

            };


        speechSynthesis.speak(
            speech
        );

    }
);