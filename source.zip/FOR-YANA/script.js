/* =========================================
   FOR YANA
========================================= */


/* =========================================
   TELEGRAM
========================================= */

const TELEGRAM_BOT_TOKEN =
  "8895730609:AAFSR_yGaH3TjCD5UtsLueRm1jLyMrm4TT4";

const TELEGRAM_CHAT_ID =
  "8844418168";


/* =========================================
   STATE
========================================= */

let currentPage = 0;

let firstAnswer = "-";

let finalAnswer = "-";

let oldIndex = 0;

let oldTimer;


/* =========================================
   ELEMENTS
========================================= */

const pages =
  document.querySelectorAll(".page");

const progress =
  document.getElementById("progress");

const topBar =
  document.getElementById("topBar");

const music =
  document.getElementById("music");

const musicBtn =
  document.getElementById("musicBtn");

const musicIcon =
  document.getElementById("musicIcon");

const memoryVideo =
  document.getElementById("memoryVideo");

const oldText =
  document.getElementById("oldText");

const oldNext =
  document.getElementById("oldNext");

const resultAnswer =
  document.getElementById("resultAnswer");

const resultText =
  document.getElementById("resultText");

const telegramStatus =
  document.getElementById(
    "telegramStatus"
  );


/* =========================================
   PAGE SYSTEM
========================================= */

function showPage(index) {

  if (index < 0) {
    index = 0;
  }

  if (index >= pages.length) {
    index = pages.length - 1;
  }


  currentPage = index;


  pages.forEach((page, i) => {

    page.classList.toggle(
      "active",
      i === index
    );

  });


  progress.textContent =
    String(index + 1).padStart(2, "0") +
    " / " +
    String(pages.length).padStart(2, "0");


  /*
    Hide header on video.
  */

  if (index === 7) {

    topBar.style.display =
      "none";

  }

  else {

    topBar.style.display =
      "flex";

  }


  /*
    Start old phone.
  */

  if (index === 5) {

    startOldPhone();

  }

}


/* =========================================
   NEXT
========================================= */

function nextPage() {

  showPage(
    currentPage + 1
  );

}


/* =========================================
   NEXT BUTTONS
========================================= */

document
  .querySelectorAll(".next-btn")
  .forEach(button => {

    button.addEventListener(
      "click",
      function(e) {

        e.preventDefault();

        e.stopPropagation();

        createSparkles(e);

        nextPage();

      }
    );

  });


/* =========================================
   FIRST QUESTION
========================================= */

document
  .querySelectorAll(
    "[data-first-answer]"
  )
  .forEach(button => {

    button.addEventListener(
      "click",
      function(e) {

        e.preventDefault();

        e.stopPropagation();


        firstAnswer =
          this.dataset.firstAnswer;


        createSparkles(e);


        setTimeout(() => {

          showPage(5);

        }, 250);

      }
    );

  });


/* =========================================
   OLD PHONE STORY
========================================= */

const oldLines = [

  "eh...",

  "tadi aku iseng buka hp lama.",

  "awalnya cuma mau nyari file yang udah lama banget nggak aku buka.",

  "terus aku nemu sesuatu...",

  "ada foto kamu.",

  "dan lah...",

  "ternyata ada aku juga di beberapa foto itu.",

  "aku sampe lupa kalau semuanya masih ada di sini.",

  "terus aku scroll lagi.",

  "satu...",

  "dua...",

  "tiga...",

  "lah kok jadi banyak banget.",

  "ada hal-hal kecil yang dulu biasa aja.",

  "tapi sekarang malah jadi kenangan.",

  "terus aku nemu satu video.",

  "awalnya aku mau tutup.",

  "tapi yaudah...",

  "aku buka lagi.",

  "kayaknya kamu harus lihat juga.",

  "udah deh...",

  "lihat sendiri aja ♡"

];


function startOldPhone() {

  clearTimeout(oldTimer);

  oldIndex = 0;

  oldText.textContent = "";

  oldNext.style.display =
    "none";

  showOldLine();

}


function showOldLine() {

  if (
    oldIndex >=
    oldLines.length
  ) {

    oldNext.style.display =
      "inline-block";

    return;

  }


  oldText.textContent =
    oldLines[oldIndex];

  oldIndex++;


  oldTimer =
    setTimeout(
      showOldLine,
      1500
    );

}


/* =========================================
   OLD PHONE NEXT
========================================= */

oldNext.addEventListener(
  "click",
  function(e) {

    e.preventDefault();

    e.stopPropagation();

    createSparkles(e);

    showPage(6);

  }
);


/* =========================================
   VIDEO
========================================= */

const openVideo =
  document.getElementById(
    "openVideo"
  );


openVideo.addEventListener(
  "click",
  function(e) {

    e.preventDefault();

    e.stopPropagation();

    createSparkles(e);


    /*
      Stop music before video.
    */

    music.pause();

    music.currentTime = 0;

    musicIcon.textContent =
      "♪";


    /*
      Show video.
    */

    showPage(7);


    setTimeout(() => {

      memoryVideo.currentTime = 0;

      const playPromise =
        memoryVideo.play();


      if (
        playPromise !== undefined
      ) {

        playPromise.catch(() => {

          memoryVideo.controls =
            true;

        });

      }

    }, 350);

  }
);


/* =========================================
   VIDEO ENDED
========================================= */

memoryVideo.addEventListener(
  "ended",
  function() {

    memoryVideo.pause();

    showPage(8);

  }
);


/* =========================================
   FINAL ANSWERS
========================================= */

document
  .querySelectorAll(
    "[data-final-answer]"
  )
  .forEach(button => {

    button.addEventListener(
      "click",
      function(e) {

        e.preventDefault();

        e.stopPropagation();


        finalAnswer =
          this.dataset.finalAnswer;


        createSparkles(e);


        setTimeout(() => {

          showResultText();

          showPage(11);

          sendToTelegram();

        }, 300);

      }
    );

  });


/* =========================================
   RESULT TEXT
========================================= */

function showResultText() {

  resultAnswer.textContent =
    finalAnswer;


  if (
    finalAnswer ===
    "IYA, KITA BALIKAN"
  ) {

    resultText.textContent =
      "AKU MAU BANGETT. kalau kamu juga mau, kita coba lagi pelan-pelan yaa.";

  }

  else if (
    finalAnswer ===
    "KITA ULANG DARI AWAL"
  ) {

    resultText.textContent =
      "iyaa, kita mulai lagi dari awal. pelan-pelan dan nggak perlu buru-buru.";

  }

  else if (
    finalAnswer ===
    "AKU MAU NGOBROL DULU"
  ) {

    resultText.textContent =
      "iyaa gapapa kokk, kita ngobrol dulu aja. santaii.";

  }

  else if (
    finalAnswer ===
    "MULAI DARI TEMAN"
  ) {

    resultText.textContent =
      "bolehh. kita mulai dari temen dulu ajaa, nggak usah buru-buru.";

  }

  else if (
    finalAnswer ===
    "AKU MASIH BINGUNG"
  ) {

    resultText.textContent =
      "gapapaa kalau masih bingung. nggak harus langsung punya jawaban kok.";

  }

  else if (
    finalAnswer ===
    "MAAF, AKU NGGAK MAU"
  ) {

    resultText.textContent =
      "iyaa, gapapa kok. makasih udah jujur yaa.";

  }

  else {

    resultText.textContent =
      "jawaban kamu udah dicatat.";

  }

}


/* =========================================
   TELEGRAM SEND
========================================= */

function telegramConfigured() {

  return (

    TELEGRAM_BOT_TOKEN &&

    TELEGRAM_CHAT_ID &&

    !TELEGRAM_BOT_TOKEN.includes(
      "ISI_TOKEN"
    ) &&

    !TELEGRAM_CHAT_ID.includes(
      "ISI_CHAT_ID"
    )

  );

}


async function sendToTelegram() {

  if (!telegramConfigured()) {

    telegramStatus.textContent =
      "TELEGRAM BELUM DIATUR";

    return;

  }


  telegramStatus.textContent =
    "NGIRIM JAWABAN...";


  let sessionId =
    localStorage.getItem(
      "yana_session"
    );


  if (!sessionId) {

    sessionId =
      Date.now().toString(36) +
      Math.random()
        .toString(36)
        .slice(2, 8);


    localStorage.setItem(
      "yana_session",
      sessionId
    );

  }


  const time =
    new Date().toLocaleString(
      "id-ID",
      {
        dateStyle:
          "full",

        timeStyle:
          "medium"
      }
    );


  const message =
`♡ FOR YANA

Jawaban pertanyaan pertama:
${firstAnswer}

Jawaban akhir:
${finalAnswer}

Session:
${sessionId}

Waktu:
${time}`;


  try {

    const response =
      await fetch(

        `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}/sendMessage`,

        {

          method:
            "POST",

          headers: {

            "Content-Type":
              "application/json"

          },

          body:
            JSON.stringify({

              chat_id:
                TELEGRAM_CHAT_ID,

              text:
                message

            })

        }

      );


    const data =
      await response.json();


    if (data.ok) {

      telegramStatus.textContent =
        "JAWABANNYA UDAH TERKIRIM ✓";

    }

    else {

      telegramStatus.textContent =
        "GAGAL NGIRIM";

      console.error(
        "Telegram error:",
        data
      );

    }

  }

  catch (error) {

    telegramStatus.textContent =
      "KONEKSI GAGAL";

    console.error(
      error
    );

  }

}


/* =========================================
   MUSIC
========================================= */

music.volume =
  0.38;


/*
  Try autoplay.
*/

async function playMusic() {

  try {

    await music.play();

    musicIcon.textContent =
      "♫";

  }

  catch (error) {

    musicIcon.textContent =
      "♪";

  }

}


/*
  Browser mungkin
  memblokir autoplay
  dengan suara.
*/

window.addEventListener(
  "load",
  () => {

    playMusic();

  }
);


/*
  Unlock music setelah
  interaksi pertama.
*/

function unlockMusic() {

  if (
    currentPage === 7
  ) {

    return;

  }


  if (
    music.paused
  ) {

    playMusic();

  }

}


document.addEventListener(
  "click",
  unlockMusic,
  {
    once: true
  }
);


document.addEventListener(
  "touchstart",
  unlockMusic,
  {
    once: true
  }
);


/*
  Music button kanan atas.
*/

musicBtn.addEventListener(
  "click",
  function(e) {

    e.preventDefault();

    e.stopPropagation();


    if (
      music.paused
    ) {

      music
        .play()
        .then(() => {

          musicIcon.textContent =
            "♫";

        })
        .catch(() => {

          musicIcon.textContent =
            "♪";

        });

    }

    else {

      music.pause();

      musicIcon.textContent =
        "♪";

    }

  }
);


/* =========================================
   FINISH
========================================= */

const finishBtn =
  document.getElementById(
    "finishBtn"
  );


finishBtn.addEventListener(
  "click",
  function(e) {

    e.preventDefault();

    e.stopPropagation();

    createSparkles(e);


    setTimeout(() => {

      showPage(0);

    }, 400);

  }
);


/* =========================================
   SPARKLES
========================================= */

function createSparkles(e) {

  const x =
    e.clientX;

  const y =
    e.clientY;


  for (
    let i = 0;
    i < 7;
    i++
  ) {

    const sparkle =
      document.createElement(
        "span"
      );


    sparkle.className =
      "sparkle";


    sparkle.style.left =
      x + "px";


    sparkle.style.top =
      y + "px";


    sparkle.style.setProperty(

      "--sx",

      (
        (Math.random() - .5)
        * 100
      ) + "px"

    );


    sparkle.style.setProperty(

      "--sy",

      (
        (Math.random() - .5)
        * 100
      ) + "px"

    );


    document.body.appendChild(
      sparkle
    );


    setTimeout(() => {

      sparkle.remove();

    }, 700);

  }

}


/* =========================================
   MOBILE SWIPE
========================================= */

let touchStartX = 0;

let touchStartY = 0;


document.addEventListener(
  "touchstart",
  function(e) {

    touchStartX =
      e.touches[0].clientX;

    touchStartY =
      e.touches[0].clientY;

  },
  {
    passive: true
  }
);


document.addEventListener(
  "touchend",
  function(e) {

    const touchEndX =
      e.changedTouches[0].clientX;

    const touchEndY =
      e.changedTouches[0].clientY;


    const diffX =
      touchEndX -
      touchStartX;

    const diffY =
      touchEndY -
      touchStartY;


    /*
      Disable swipe on choices.
    */

    if (
      currentPage === 4 ||
      currentPage === 10
    ) {

      return;

    }


    /*
      Disable swipe
      during video.
    */

    if (
      currentPage === 7
    ) {

      return;

    }


    if (

      Math.abs(diffX) > 80 &&

      Math.abs(diffX) >
      Math.abs(diffY)

    ) {

      if (
        diffX < 0
      ) {

        nextPage();

      }

      else if (

        diffX > 0 &&

        currentPage > 0

      ) {

        showPage(
          currentPage - 1
        );

      }

    }

  },
  {
    passive: true
  }
);


/* =========================================
   INITIAL PAGE
========================================= */

showPage(0);